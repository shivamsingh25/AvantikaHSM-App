<?php
include('phpqrcode/qrlib.php'); 
$otp=$_GET['otp'];
if($otp){
    QRcode::png($otp,false,QR_ECLEVEL_L, 10); 
}
?>